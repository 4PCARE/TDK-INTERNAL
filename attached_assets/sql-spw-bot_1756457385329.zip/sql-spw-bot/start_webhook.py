
import os
import threading
import time
from webhook_handler import app, load_app_data

def start_webhook_server():
    """Start the webhook server"""
    print("Starting LINE webhook server...")
    load_app_data()
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)

if __name__ == "__main__":
    # Start webhook server in a separate thread
    webhook_thread = threading.Thread(target=start_webhook_server)
    webhook_thread.daemon = True
    webhook_thread.start()
    
    print("LINE webhook server is running on port 5000")
    print("Webhook URL: {}/webhook/line".format(os.getenv('REPL_URL', 'https://your-repl-name.username.repl.co')))
    
    # Keep the main thread alive
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Shutting down webhook server...")
