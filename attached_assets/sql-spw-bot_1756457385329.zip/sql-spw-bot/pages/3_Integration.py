
import streamlit as st
import requests
import json
import hashlib
import hmac
import base64
from urllib.parse import urlencode
import os

st.set_page_config(page_title="Integration • SQL Chat", page_icon="🔗", layout="wide")
st.title("🔗 LINE Integration")

# Initialize session state for LINE config
if "line_config" not in st.session_state:
    # Try to load existing credentials
    default_config = {
        "channel_id": "",
        "channel_secret": "",
        "channel_access_token": "",
        "verified": False
    }
    
    # Load from saved config if it exists
    try:
        import json
        with open("config/line_config.json", "r") as f:
            saved_config = json.load(f)
            default_config.update(saved_config)
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    
    st.session_state.line_config = default_config

line_config = st.session_state.line_config

st.subheader("LINE Bot Configuration")

# Input fields for LINE credentials
col1, col2 = st.columns(2)
with col1:
    channel_id = st.text_input(
        "Channel ID", 
        value=line_config["channel_id"],
        help="Your LINE Bot Channel ID"
    )
    channel_secret = st.text_input(
        "Channel Secret", 
        value=line_config["channel_secret"],
        type="password",
        help="Your LINE Bot Channel Secret"
    )

with col2:
    channel_access_token = st.text_area(
        "Channel Access Token", 
        value=line_config["channel_access_token"],
        height=100,
        help="Your LINE Bot Channel Access Token"
    )

# Save credentials
if st.button("Save Credentials"):
    line_config["channel_id"] = channel_id
    line_config["channel_secret"] = channel_secret
    line_config["channel_access_token"] = channel_access_token
    
    # Also save to a persistent config file
    line_credentials = {
        "channel_id": channel_id,
        "channel_secret": channel_secret,
        "channel_access_token": channel_access_token
    }
    
    # Save to config directory
    os.makedirs("config", exist_ok=True)
    import json
    with open("config/line_config.json", "w") as f:
        json.dump(line_credentials, f, indent=2)
    
    st.success("Credentials saved to config/line_config.json!")

st.divider()

# Verification section
st.subheader("Verify LINE Connection")

def verify_line_connection(access_token):
    """Verify LINE Bot connection by checking bot info"""
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(
            "https://api.line.me/v2/bot/info",
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            bot_info = response.json()
            return True, bot_info
        else:
            return False, f"Error {response.status_code}: {response.text}"
    except Exception as e:
        return False, str(e)

if st.button("Verify Connection"):
    if not line_config["channel_access_token"]:
        st.error("Please enter a Channel Access Token first")
    else:
        with st.spinner("Verifying connection..."):
            success, result = verify_line_connection(line_config["channel_access_token"])
            
            if success:
                st.success("✅ LINE connection verified!")
                st.json(result)
                line_config["verified"] = True
            else:
                st.error(f"❌ Verification failed: {result}")
                line_config["verified"] = False

st.divider()

# Webhook URL section
st.subheader("Webhook Configuration")

# Get the current Replit URL
replit_dev_domain = os.getenv('REPLIT_DEV_DOMAIN')
if replit_dev_domain:
    webhook_url = f"https://{replit_dev_domain}:5000/webhook/line"
else:
    # Fallback - construct from environment
    repl_slug = os.getenv('REPL_SLUG', 'your-repl-name')
    repl_owner = os.getenv('REPL_OWNER', 'username')
    webhook_url = f"https://{repl_slug}.{repl_owner}.repl.co:5000/webhook/line"

st.code(webhook_url, language="text")
st.caption("📋 Copy this webhook URL and paste it in your LINE Developer Console")

# Instructions
with st.expander("Setup Instructions"):
    st.markdown("""
    ### How to set up your LINE webhook:
    
    1. **Get your LINE Bot credentials:**
       - Go to [LINE Developer Console](https://developers.line.biz/console/)
       - Select your provider and channel
       - Copy the Channel ID, Channel Secret, and Channel Access Token
    
    2. **Configure webhook in LINE:**
       - In your LINE Developer Console, go to "Messaging API" tab
       - Set the webhook URL to the one shown above
       - Enable "Use webhook"
       - Verify the webhook (it should return 200 OK)
    
    3. **Test your bot:**
       - Add your bot as a friend using QR code or Bot ID
       - Send a message to test the integration
    """)

# Webhook endpoint status
st.divider()
st.subheader("Webhook Status")

if line_config["verified"]:
    st.success("🟢 LINE Bot configured and verified")
    st.info("Your webhook endpoint is ready to receive messages!")
else:
    st.warning("🟡 Please verify your LINE connection first")

# Data selection for responses
if line_config["verified"]:
    st.divider()
    st.subheader("Response Data Configuration")
    
    # Load app config to access current data settings
    if "app_config" not in st.session_state:
        from modules.config_manager import load_config
        st.session_state.app_config = load_config()
    
    cfg = st.session_state.app_config
    
    st.info(f"Currently using data from: `{cfg.data.file_path}`")
    st.info(f"Table name: `{cfg.data.table_name}`")
    
    st.caption("The LINE bot will use the same data source configured in the Config page. Users can ask questions about this data via LINE messages.")
