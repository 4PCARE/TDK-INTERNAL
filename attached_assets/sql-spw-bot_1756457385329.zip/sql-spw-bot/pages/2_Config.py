import os
import streamlit as st
import yaml
import copy
from modules.config_manager import load_config, save_config, AppConfig, AIConfig, DataConfig, Snippet
from modules import sql_engine

st.set_page_config(page_title="Config • SQL Chat", page_icon="⚙️", layout="wide")
st.title("⚙️ Config")

if "app_config" not in st.session_state:
    st.session_state.app_config = load_config()

# Initialize autosave state
if "config_backup" not in st.session_state:
    st.session_state.config_backup = copy.deepcopy(st.session_state.app_config)

if "autosave_enabled" not in st.session_state:
    st.session_state.autosave_enabled = True

cfg: AppConfig = st.session_state.app_config

# Autosave and Undo controls at the top
col1, col2, col3 = st.columns([2, 1, 1])
with col1:
    st.session_state.autosave_enabled = st.toggle("🔄 Autosave", value=st.session_state.autosave_enabled, help="Automatically save changes")
with col2:
    if st.button("↶ Undo", help="Restore previous configuration"):
        st.session_state.app_config = copy.deepcopy(st.session_state.config_backup)
        st.success("Configuration restored!")
        st.rerun()
with col3:
    if st.button("💾 Save Now", type="primary"):
        save_config(st.session_state.app_config)
        st.session_state.config_backup = copy.deepcopy(st.session_state.app_config)
        st.success("Configuration saved!")

def autosave_if_enabled():
    """Helper function to autosave if enabled"""
    if st.session_state.autosave_enabled:
        save_config(st.session_state.app_config)
        # Update backup after successful save
        st.session_state.config_backup = copy.deepcopy(st.session_state.app_config)

st.divider()

st.subheader("AI Settings")
c1, c2 = st.columns([1,1])
with c1:
    provider = st.selectbox("Provider", ["openai"], index=0)
    if provider != cfg.ai.provider:
        cfg.ai.provider = provider
        autosave_if_enabled()
with c2:
    model = st.text_input("Model", value=cfg.ai.model, help="e.g., gpt-4o-mini")
    if model != cfg.ai.model:
        cfg.ai.model = model
        autosave_if_enabled()

c1, c2, c3 = st.columns(3)
with c1:
    temperature = st.slider("SQL Temperature", 0.0, 1.0, value=float(cfg.ai.temperature), step=0.1, help="Temperature for SQL generation (lower = more deterministic)")
    if temperature != cfg.ai.temperature:
        cfg.ai.temperature = float(temperature)
        autosave_if_enabled()
with c2:
    agent_temperature = st.slider("Agent Temperature", 0.0, 1.0, value=float(cfg.ai.agent_temperature), step=0.1, help="Temperature for user-facing responses (higher = more creative)")
    if agent_temperature != cfg.ai.agent_temperature:
        cfg.ai.agent_temperature = float(agent_temperature)
        autosave_if_enabled()
with c3:
    offline = st.toggle("Offline Demo Mode", value=cfg.ai.offline_demo_mode, help="Use rule-based SQL generation instead of AI models")
    if offline != cfg.ai.offline_demo_mode:
        cfg.ai.offline_demo_mode = bool(offline)
        autosave_if_enabled()

c1, c2, col3 = st.columns(3)
with c1:
    pass # The 'offline' toggle is handled above.
with c2:
    use_bm25 = st.checkbox(
        "Use BM25 Similarity",
        cfg.ai.use_bm25_similarity,
        help="Use BM25 scoring for snippet matching (vs simple Jaccard similarity)"
    )
    if use_bm25 != cfg.ai.use_bm25_similarity:
        cfg.ai.use_bm25_similarity = use_bm25
        autosave_if_enabled()
with col3:
    use_embedding = st.checkbox(
        "Use Embedding Similarity",
        cfg.ai.use_embedding_similarity,
        help="Use OpenAI embeddings for semantic snippet matching (requires API key)"
    )
    if use_embedding != cfg.ai.use_embedding_similarity:
        cfg.ai.use_embedding_similarity = use_embedding
        autosave_if_enabled()

# Add max rows configuration
st.subheader("Data Processing Settings")
max_rows = st.number_input(
    "Maximum rows for AI processing",
    min_value=1,
    max_value=1000,
    value=cfg.ai.max_rows_for_ai,
    step=10,
    help="Maximum number of rows to send to AI agent for analysis. Higher values may hit context limits but provide more complete analysis."
)
if max_rows != cfg.ai.max_rows_for_ai:
    cfg.ai.max_rows_for_ai = int(max_rows)
    autosave_if_enabled()

sys_prompt = st.text_area("System Prompt (Answering)", value=cfg.ai.system_prompt, height=140)
if sys_prompt != cfg.ai.system_prompt:
    cfg.ai.system_prompt = sys_prompt
    autosave_if_enabled()

sql_prompt = st.text_area("SQL Synthesizer Prompt", value=cfg.ai.sql_synth_prompt, height=160)
if sql_prompt != cfg.ai.sql_synth_prompt:
    cfg.ai.sql_synth_prompt = sql_prompt
    autosave_if_enabled()

st.divider()
st.subheader("Data Settings")
d1, d2 = st.columns([2,1])
with d1:
    file_path = st.text_input("Data file path (.csv or .xlsx)", value=cfg.data.file_path)
    if file_path != cfg.data.file_path:
        cfg.data.file_path = file_path
        autosave_if_enabled()
with d2:
    table_name = st.text_input("Table name", value=cfg.data.table_name)
    if table_name != cfg.data.table_name:
        cfg.data.table_name = table_name
        autosave_if_enabled()

details = st.text_area("Additional details (for the model)", value=cfg.data.additional_details, height=130)
if details != cfg.data.additional_details:
    cfg.data.additional_details = details
    autosave_if_enabled()

build = st.button("Rebuild In-Memory Table")
if build:
    try:
        eng = sql_engine.build_engine_from_file(file_path, table_name)
        st.session_state.engine = eng
        st.session_state.engine_src = (file_path, table_name)
        st.success("Rebuilt table successfully.")
    except Exception as e:
        st.error(f"Failed: {e}")

with st.expander("Preview Schema"):
    if "engine" in st.session_state:
        st.code(st.session_state.engine.schema_text(), language="sql")
    else:
        st.info("No engine yet — open Chat once or click Rebuild.")

st.divider()
st.subheader("SQL Snippets")

# Show embedding status
if cfg.snippets:
    embeddings_count = sum(1 for s in cfg.snippets if s.embedding)
    total_snippets = len(cfg.snippets)
    st.info(f"🧠 Embeddings: {embeddings_count}/{total_snippets} snippets have embeddings")

    if embeddings_count < total_snippets:
        if st.button("🔄 Generate Missing Embeddings"):
            with st.spinner("Generating embeddings..."):
                from modules.config_manager import ensure_snippets_have_embeddings
                cfg.snippets = ensure_snippets_have_embeddings(cfg.snippets)
                st.success("Embeddings generated!")
                st.rerun()

# --- initialize working list in session_state ---
if "snips" not in st.session_state:
    # make a shallow copy of dataclass instances; adjust if you need deep copy
    st.session_state.snips = [Snippet(name=s.name, sql=s.sql, embedding=s.embedding) for s in cfg.snippets]

snips = st.session_state.snips  # alias for brevity

# --- existing items (editable + deletable) ---
delete_indices = []
for i, s in enumerate(snips):
    with st.container(border=True):
        n = st.text_input(f"Name #{i+1}", value=s.name, key=f"sn-name-{i}")
        d = st.text_input(f"Description #{i+1}", value=s.description, key=f"sn-desc-{i}", help="Description of what this query does")
        q = st.text_area(f"SQL #{i+1}", value=s.sql, key=f"sn-sql-{i}", height=80)
        if st.button(f"Delete #{i+1}", key=f"sn-del-{i}"):
            delete_indices.append(i)
        else:
            # write edits back into the working list
            if n != s.name or d != s.description or q != s.sql:
                snips[i] = Snippet(name=n, sql=q, description=d, embedding=s.embedding) # Keep embedding
                cfg.snippets = snips
                autosave_if_enabled()

# apply deletions after the loop to avoid index shifts
if delete_indices:
    for idx in sorted(delete_indices, reverse=True):
        snips.pop(idx)
        # also clean up any orphaned widget state for neatness
        st.session_state.pop(f"sn-name-{idx}", None)
        st.session_state.pop(f"sn-desc-{idx}", None)
        st.session_state.pop(f"sn-sql-{idx}", None)
    # Update config and autosave after deletions
    cfg.snippets = snips
    autosave_if_enabled()

# --- add new snippet (works across reruns) ---
with st.container(border=True):
    st.markdown("**Add a snippet**")
    # Use default values that get cleared after successful addition
    default_name = st.session_state.get("new-sn-n", "")
    default_desc = st.session_state.get("new-sn-d", "")
    default_sql = st.session_state.get("new-sn-s", "")

    newn = st.text_input("New snippet name", value=default_name, key="new-sn-n")
    newd = st.text_input("New snippet description", value=default_desc, key="new-sn-d", help="Description of what this query does")
    news = st.text_area("New snippet SQL", value=default_sql, key="new-sn-s", height=60)
    if st.button("Add snippet"):
        if newn and news:
            new_snippet = Snippet(name=newn, sql=news, description=newd)
            # Generate embedding immediately if possible
            from modules.config_manager import generate_snippet_embedding
            new_snippet.embedding = generate_snippet_embedding(new_snippet)
            snips.append(new_snippet)
            cfg.snippets = snips
            autosave_if_enabled()
            st.success(f"Added snippet: {newn}")
            st.rerun()  # Rerun to clear the form
        else:
            st.warning("Provide both name and SQL.")


st.divider()
st.subheader("Secrets")
api_key = st.text_input("OPENAI_API_KEY", type="password", help="If set here, it will be exported to the process for this session.")
if api_key:
    os.environ["OPENAI_API_KEY"] = api_key
    st.success("OPENAI_API_KEY set for this process.")

st.divider()
if st.session_state.autosave_enabled:
    st.info("💡 **Autosave is enabled** - Changes are automatically saved as you make them")
else:
    st.warning("⚠️ **Autosave is disabled** - Remember to click 'Save Now' to persist your changes")
    
# Status indicator
if st.session_state.autosave_enabled:
    st.success("✅ All changes are automatically saved")