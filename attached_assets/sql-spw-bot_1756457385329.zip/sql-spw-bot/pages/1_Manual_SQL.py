
import streamlit as st
from modules.ui_css import inject
from modules.config_manager import load_config
from modules import sql_engine
import pandas as pd

st.set_page_config(page_title="Manual SQL • SQL Chat", page_icon="🔍", layout="wide")

inject()
st.title("🔍 Manual SQL")
st.caption("Execute custom SQL queries directly against your data.")

# Load config
if "app_config" not in st.session_state:
    st.session_state.app_config = load_config()
cfg = st.session_state.app_config

# Build or rebuild engine if needed
if "engine" not in st.session_state or st.session_state.get("engine_src") != (cfg.data.file_path, cfg.data.table_name):
    try:
        eng = sql_engine.build_engine_from_file(cfg.data.file_path, cfg.data.table_name)
        st.session_state.engine = eng
        st.session_state.engine_src = (cfg.data.file_path, cfg.data.table_name)
    except Exception as e:
        st.error(f"Failed to load data: {e}")
        st.stop()

engine = st.session_state.engine

# Sidebar with schema info
with st.sidebar:
    st.subheader("Database Schema")
    st.markdown("**Table:** `" + cfg.data.table_name + "`")
    with st.expander("Schema Details", expanded=True):
        st.code(engine.schema_text(), language="sql")
    
    st.markdown("---")
    st.subheader("Query Examples")
    st.code(f'SELECT * FROM "{cfg.data.table_name}" LIMIT 10;', language="sql")
    st.code(f'SELECT COUNT(*) FROM "{cfg.data.table_name}";', language="sql")
    if cfg.data.table_name == "sales":
        st.code(f'SELECT product, SUM(revenue) FROM "{cfg.data.table_name}" GROUP BY product ORDER BY SUM(revenue) DESC;', language="sql")

# Main content area
col1, col2 = st.columns([3, 1])

with col1:
    st.subheader("SQL Query")
    
    # Initialize query in session state if not exists
    if "manual_sql_query" not in st.session_state:
        st.session_state.manual_sql_query = f'SELECT * FROM "{cfg.data.table_name}" LIMIT 10;'
    
    sql_query = st.text_area(
        "Enter your SQL query:",
        value=st.session_state.manual_sql_query,
        height=150,
        help="Only SELECT, WITH, and other read-only queries are allowed for security."
    )
    
    # Update session state when query changes
    st.session_state.manual_sql_query = sql_query

with col2:
    st.subheader("Actions")
    execute_button = st.button("Execute Query", type="primary", use_container_width=True)
    
    if st.button("Clear Query", use_container_width=True):
        st.session_state.manual_sql_query = ""
        st.rerun()
    
    if st.button("Reset to Default", use_container_width=True):
        st.session_state.manual_sql_query = f'SELECT * FROM "{cfg.data.table_name}" LIMIT 10;'
        st.rerun()

# Query execution
if execute_button and sql_query.strip():
    with st.spinner("Executing query..."):
        try:
            columns, rows = engine.execute_safe_select(sql_query)
            
            st.success(f"✅ Query executed successfully! Retrieved {len(rows)} row(s).")
            
            if rows:
                # Convert to DataFrame for better display
                df = pd.DataFrame(rows)
                
                # Display results
                st.subheader("Query Results")
                
                # Show result summary
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Rows", len(rows))
                with col2:
                    st.metric("Columns", len(columns))
                with col3:
                    if df.select_dtypes(include=['number']).empty:
                        st.metric("Numeric Cols", 0)
                    else:
                        st.metric("Numeric Cols", len(df.select_dtypes(include=['number']).columns))
                
                # Display the data table
                st.dataframe(
                    df, 
                    use_container_width=True, 
                    hide_index=True,
                    height=400
                )
                
                # Show download option
                csv = df.to_csv(index=False)
                st.download_button(
                    label="Download as CSV",
                    data=csv,
                    file_name=f"query_results_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
                
                # Show basic statistics for numeric columns
                numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
                if numeric_cols:
                    with st.expander("Quick Statistics"):
                        st.dataframe(df[numeric_cols].describe(), use_container_width=True)
                
            else:
                st.info("Query executed successfully but returned no rows.")
                
        except Exception as e:
            st.error(f"❌ Query failed: {e}")
            
            # Provide helpful error suggestions
            error_str = str(e).lower()
            if "only select/with" in error_str or "read-only queries" in error_str:
                st.warning("💡 **Tip:** Only SELECT, WITH, and other read-only queries are allowed. Avoid INSERT, UPDATE, DELETE, CREATE, DROP statements.")
            elif "no such column" in error_str:
                st.warning("💡 **Tip:** Check the schema in the sidebar to see available column names. Column names with special characters need to be quoted with double quotes.")
            elif "syntax error" in error_str:
                st.warning("💡 **Tip:** Check your SQL syntax. Make sure you're using proper SQLite syntax.")
            elif "no such table" in error_str:
                st.warning(f"💡 **Tip:** Make sure you're referencing the correct table name: `{cfg.data.table_name}`")

elif execute_button and not sql_query.strip():
    st.warning("Please enter a SQL query before executing.")

# Query history (optional feature)
st.markdown("---")
with st.expander("Query History"):
    if "sql_history" not in st.session_state:
        st.session_state.sql_history = []
    
    if execute_button and sql_query.strip() and sql_query not in st.session_state.sql_history:
        st.session_state.sql_history.insert(0, sql_query)
        # Keep only last 10 queries
        st.session_state.sql_history = st.session_state.sql_history[:10]
    
    if st.session_state.sql_history:
        for i, hist_query in enumerate(st.session_state.sql_history):
            col1, col2 = st.columns([4, 1])
            with col1:
                st.code(hist_query[:100] + "..." if len(hist_query) > 100 else hist_query, language="sql")
            with col2:
                if st.button("Use", key=f"hist_{i}"):
                    st.session_state.manual_sql_query = hist_query
                    st.rerun()
    else:
        st.info("No query history yet. Execute some queries to see them here.")
