import os
import streamlit as st
from modules.ui_css import inject
from modules.config_manager import load_config, save_config
from modules import sql_engine
from modules.ai_agent import synthesize_sql, answer_with_data, pick_most_related

st.set_page_config(page_title="SQL Chat", page_icon="💬", layout="wide")

inject()
st.title("💬 SQL Chat")
st.caption("LangChain-powered demo. Data from a local CSV/Excel simulated as a SQL table.")

# Load config
if "app_config" not in st.session_state:
    st.session_state.app_config = load_config()
cfg = st.session_state.app_config

# Build or rebuild engine if needed
if "engine" not in st.session_state or st.session_state.get("engine_src") != (cfg.data.file_path, cfg.data.table_name):
    try:
        eng = sql_engine.build_engine_from_file(cfg.data.file_path, cfg.data.table_name)
        st.session_state.engine = eng
        st.session_state.engine_src = (cfg.data.file_path, cfg.data.table_name)
    except Exception as e:
        st.error(f"Failed to load data: {e}")
        st.stop()

engine = st.session_state.engine

# sidebar status & controls
with st.sidebar:
    st.title("Chat with Your Data 💬")
    use_bm25 = st.toggle("Use BM25 Similarity", value=True, help="Use BM25 for better text matching")

    # Check if embeddings are actually available
    embedding_available = (not cfg.ai.offline_demo_mode and
                         os.getenv("OPENAI_API_KEY") and
                         any(s.embedding is not None for s in cfg.snippets))

    use_embedding = st.toggle("Use Embedding Similarity",
                            value=getattr(cfg.ai, 'use_embedding_similarity', False),
                            help="Use OpenAI embeddings for semantic similarity",
                            disabled=not embedding_available)

    if not embedding_available:
        if cfg.ai.offline_demo_mode:
            st.warning("🔧 Embeddings disabled: Offline demo mode")
        elif not os.getenv("OPENAI_API_KEY"):
            st.warning("🔑 Embeddings disabled: No API key")
        elif not any(s.embedding is not None for s in cfg.snippets):
            st.warning("📊 Embeddings disabled: No snippet embeddings found")
    st.markdown("---")
    st.markdown("**Table:** `" + cfg.data.table_name + "`")
    with st.expander("Schema (auto-inferred)"):
        st.code(engine.schema_text(), language="sql")

# Chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

user_input = st.chat_input("Ask about your data… (e.g., top 3 items by revenue)")
if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    # Agent: pick most-related SQL from snippets (fresh search for each query)
    snippet_list = [{"name": s.name, "sql": s.sql, "description": s.description, "embedding": s.embedding} for s in cfg.snippets]
    use_bm25 = getattr(cfg.ai, 'use_bm25_similarity', True)
    use_embedding = getattr(cfg.ai, 'use_embedding_similarity', False) # New config for embedding similarity

    # Ensure fresh search by clearing any cached results
    if "cached_candidate_sql" in st.session_state:
        del st.session_state.cached_candidate_sql
    if "cached_query" in st.session_state:
        del st.session_state.cached_query

    # Fresh similarity search for each new query - now returns top 3
    candidate_snippets = pick_most_related(user_input, snippet_list, use_bm25=use_bm25)

    # Debug: Show which examples were selected (top 3)
    if candidate_snippets and snippet_list:
        if use_embedding:
            method = "Embedding"
        elif use_bm25:
            method = "BM25"
        else:
            method = "Jaccard"
        
        st.sidebar.success(f"🎯 Found {len(candidate_snippets)} examples ({method})")
        
        with st.sidebar.expander("Top Candidate Examples"):
            for item in candidate_snippets:
                snippet = item["snippet"]
                score = item["score"]
                rank = item["rank"]
                
                st.write(f"**#{rank}** (Score: {score:.3f})")
                st.write(f"**Name:** {snippet['name'][:40]}...")
                if snippet.get('description'):
                    st.write(f"**Description:** {snippet['description'][:60]}...")
                st.code(snippet['sql'][:100] + "..." if len(snippet['sql']) > 100 else snippet['sql'], language="sql")
                st.write("---")

            # Show debug info in expander
            with st.sidebar.expander("🔍 Snippet Matching Debug"):
                st.write(f"**Query:** {user_input}")
                st.write(f"**Method:** {method}")
                st.write(f"**Total snippets:** {len(snippet_list)}")

                # Show embedding status
                embeddings_count = sum(1 for s in snippet_list if s.get("embedding"))
                st.write(f"**Snippets with embeddings:** {embeddings_count}/{len(snippet_list)}")

                if use_embedding and embeddings_count == 0:
                    st.warning("⚠️ Embedding similarity enabled but no snippets have embeddings!")

                st.write(f"**Top candidates found:** {len(candidate_snippets)}")
                for item in candidate_snippets:
                    snippet = item["snippet"]
                    has_embedding = '✅' if snippet.get('embedding') else '❌'
                    st.write(f"**#{item['rank']} has embedding:** {has_embedding}")
    elif not snippet_list:
        st.sidebar.info("ℹ️ No SQL examples configured")
    else:
        st.sidebar.warning("⚠️ No matching examples found")

    # Compose inputs for SQL synthesis
    schema = engine.schema_text()
    details = cfg.data.additional_details

    # Call AI (or offline) to synthesize SQL with retry logic
    sql_query = None
    error_text = None
    cols, rows = [], []
    max_retries = 2

    for attempt in range(max_retries + 1):
        # Include error from previous attempt in the synthesis with specific guidance
        error_context = ""
        if attempt > 0 and error_text:
            if "Only SELECT/WITH" in error_text or "read-only queries" in error_text:
                error_context = f"\n\nIMPORTANT: Previous attempt failed because the SQL was not a SELECT query. The error was: {error_text}\nYou MUST generate a SELECT query that starts with 'SELECT' or 'WITH'. Do not use INSERT, UPDATE, DELETE, CREATE, DROP, or any other non-SELECT statements."
            else:
                error_context = f"\n\nPrevious attempt failed with error: {error_text}\nPlease fix the SQL to avoid this error."

        sql_query = synthesize_sql(
            cfg={
                "ai": {
                    "provider": cfg.ai.provider,
                    "model": cfg.ai.model,
                    "temperature": cfg.ai.temperature,
                    "offline_demo_mode": cfg.ai.offline_demo_mode,
                    "system_prompt": cfg.ai.system_prompt,
                    "sql_synth_prompt": cfg.ai.sql_synth_prompt,
                }
            },
            user_query=user_input + error_context,
            schema=schema,
            details=details,
            candidate_snippets=candidate_snippets,
            table_name=cfg.data.table_name,
            max_rows=getattr(cfg.ai, 'max_rows_for_ai', 50),
        )

        # Try to run SQL
        try:
            cols, rows = engine.execute_safe_select(sql_query)
            
            # Post-process with pandas if we have too many rows
            max_rows_for_ai = getattr(cfg.ai, 'max_rows_for_ai', 50)
            if len(rows) > max_rows_for_ai:
                # Convert to DataFrame, limit rows, then back to list of dicts
                import pandas as pd
                df = pd.DataFrame(rows)
                df = df.iloc[:max_rows_for_ai]
                rows = df.to_dict('records')
            
            error_text = None  # Success!
            break
        except Exception as e:
            error_text = f"SQL failed: {e}"
            # Add debug info for non-SELECT query errors
            if "Only SELECT/WITH" in str(e) or "read-only queries" in str(e):
                # Show what the SQL actually looks like for debugging
                sql_preview = sql_query.strip()[:100] + "..." if len(sql_query.strip()) > 100 else sql_query.strip()
                error_text = f"SQL failed: {e}\nGenerated SQL preview: {sql_preview}"
            # If this is the last attempt, we'll keep the error
            if attempt == max_retries:
                cols, rows = [], []

    # Initialize expander states in session state if not exists
    if "sql_expander_expanded" not in st.session_state:
        st.session_state.sql_expander_expanded = False
    if "data_expander_expanded" not in st.session_state:
        st.session_state.data_expander_expanded = False

    # Show assistant message
    with st.chat_message("assistant"):
        with st.expander("**SQL used:**", expanded=st.session_state.sql_expander_expanded):
            st.code(sql_query, language="sql")

        if error_text:
            st.error(f"❌ {error_text}")
            if attempt > 0:
                st.warning(f"⚠️ SQL generation failed after {attempt + 1} attempts. Please try rephrasing your question or check if the requested columns exist in the data.")
        else:
            if attempt > 0:
                st.success(f"✅ SQL generated successfully after {attempt + 1} attempt(s)")
            
            # Show data processing info
            total_rows = len(rows)
            max_rows_for_ai = getattr(cfg.ai, 'max_rows_for_ai', 50)
            ai_rows = min(total_rows, max_rows_for_ai)
            
            if total_rows > max_rows_for_ai:
                st.info(f"📊 Found {total_rows} rows. Analyzing first {ai_rows} rows for AI processing. (Configurable in Settings)")
            
            with st.expander("**Data preview:**", expanded=st.session_state.data_expander_expanded):
                st.dataframe(rows, use_container_width=True, hide_index=True)

        # Ask LLM (or fallback) to narrate
        try:
            if error_text:
                # If SQL failed completely, let the answer bot explain what went wrong
                answer = answer_with_data(
                    cfg={
                        "ai": {
                            "provider": cfg.ai.provider,
                            "model": cfg.ai.model,
                            "temperature": cfg.ai.temperature,
                            "offline_demo_mode": cfg.ai.offline_demo_mode,
                            "system_prompt": cfg.ai.system_prompt,
                            "sql_synth_prompt": cfg.ai.sql_synth_prompt,
                        }
                    },
                    user_query=user_input,
                    sql=sql_query,
                    columns=cols,
                    rows=rows,
                    error_message=error_text,
                )
            else:
                answer = answer_with_data(
                    cfg={
                        "ai": {
                            "provider": cfg.ai.provider,
                            "model": cfg.ai.model,
                            "temperature": cfg.ai.temperature,
                            "offline_demo_mode": cfg.ai.offline_demo_mode,
                            "system_prompt": cfg.ai.system_prompt,
                            "sql_synth_prompt": cfg.ai.sql_synth_prompt,
                        }
                    },
                    user_query=user_input,
                    sql=sql_query,
                    columns=cols,
                    rows=rows,
                )
        except Exception as e:
            answer = f"(Answer generator failed: {e})"
        st.markdown(answer)

    st.session_state.messages.append({"role": "assistant", "content": answer})