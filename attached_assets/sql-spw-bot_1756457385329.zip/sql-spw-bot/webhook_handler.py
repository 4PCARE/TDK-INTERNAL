
from flask import Flask, request, abort
import json
import hashlib
import hmac
import base64
import os
import requests
from modules.config_manager import load_config
from modules import sql_engine
from modules.ai_agent import synthesize_sql, answer_with_data, pick_most_related

app = Flask(__name__)

# Global variables for caching
engine = None
config = None

def load_app_data():
    """Load configuration and database engine"""
    global engine, config
    try:
        config = load_config()
        engine = sql_engine.build_engine_from_file(
            config.data.file_path, 
            config.data.table_name
        )
        return True
    except Exception as e:
        print(f"Failed to load app data: {e}")
        return False

def verify_line_signature(body, signature, channel_secret):
    """Verify LINE webhook signature"""
    hash_digest = hmac.new(
        channel_secret.encode('utf-8'),
        body,
        hashlib.sha256
    ).digest()
    expected_signature = base64.b64encode(hash_digest).decode('utf-8')
    return hmac.compare_digest(signature, expected_signature)

def send_line_reply(reply_token, message, access_token):
    """Send reply message to LINE"""
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    
    data = {
        'replyToken': reply_token,
        'messages': [{
            'type': 'text',
            'text': message
        }]
    }
    
    response = requests.post(
        'https://api.line.me/v2/bot/message/reply',
        headers=headers,
        data=json.dumps(data)
    )
    
    return response.status_code == 200

def process_user_query(user_message):
    """Process user query and return SQL result"""
    global engine, config
    
    if not engine or not config:
        if not load_app_data():
            return "Sorry, the system is not properly configured."
    
    try:
        # Get most related SQL snippet
        snippet_list = [{"name": s.name, "sql": s.sql, "embedding": s.embedding} for s in config.snippets]
        use_bm25 = getattr(config.ai, 'use_bm25_similarity', True)
        use_embedding = getattr(config.ai, 'use_embedding_similarity', False)
        
        candidate_snippets = pick_most_related(
            user_message, 
            snippet_list,
            use_bm25=use_bm25
        )
        
        # Get max rows configuration
        max_rows_for_ai = getattr(config.ai, 'max_rows_for_ai', 50)
        
        # Call AI (or offline) to synthesize SQL with retry logic
        sql_query = None
        error_text = None
        columns, rows = [], []
        max_retries = 2
        
        for attempt in range(max_retries + 1):
            # Include error from previous attempt in the synthesis with specific guidance
            error_context = ""
            if attempt > 0 and error_text:
                if "Only SELECT/WITH" in error_text or "read-only queries" in error_text:
                    error_context = f"\n\nIMPORTANT: Previous attempt failed because the SQL was not a SELECT query. The error was: {error_text}\nYou MUST generate a SELECT query that starts with 'SELECT' or 'WITH'. Do not use INSERT, UPDATE, DELETE, CREATE, DROP, or any other non-SELECT statements."
                else:
                    error_context = f"\n\nPrevious attempt failed with error: {error_text}\nPlease fix the SQL to avoid this error."
            
            sql_query = synthesize_sql(
                cfg={
                    "ai": {
                        "provider": config.ai.provider,
                        "model": config.ai.model,
                        "temperature": config.ai.temperature,
                        "offline_demo_mode": config.ai.offline_demo_mode,
                        "system_prompt": config.ai.system_prompt,
                        "sql_synth_prompt": config.ai.sql_synth_prompt,
                    }
                },
                user_query=user_message + error_context,
                schema=engine.schema_text(),
                details=config.data.additional_details,
                candidate_snippets=candidate_snippets,
                table_name=config.data.table_name,
                max_rows=getattr(config.ai, 'max_rows_for_ai', 50)
            )

            # Try to run SQL
            try:
                columns, rows = engine.execute_safe_select(sql_query)
                
                # Post-process with pandas if we have too many rows
                max_rows_for_ai = getattr(config.ai, 'max_rows_for_ai', 50)
                if len(rows) > max_rows_for_ai:
                    # Convert to DataFrame, limit rows, then back to list of dicts
                    import pandas as pd
                    df = pd.DataFrame(rows)
                    df = df.iloc[:max_rows_for_ai]
                    rows = df.to_dict('records')
                
                error_text = None  # Success!
                break
            except Exception as e:
                error_text = f"SQL failed: {e}"
                # Add debug info for non-SELECT query errors
                if "Only SELECT/WITH" in str(e) or "read-only queries" in str(e):
                    # Show what the SQL actually looks like for debugging
                    sql_preview = sql_query.strip()[:100] + "..." if len(sql_query.strip()) > 100 else sql_query.strip()
                    error_text = f"SQL failed: {e}\nGenerated SQL preview: {sql_preview}"
                # If this is the last attempt, we'll keep the error
                if attempt == max_retries:
                    columns, rows = [], []
        
        # Generate natural language answer
        if error_text:
            # If SQL failed completely, let the answer bot explain what went wrong
            answer = answer_with_data(
                cfg={
                    "ai": {
                        "provider": config.ai.provider,
                        "model": config.ai.model,
                        "temperature": config.ai.temperature,
                        "offline_demo_mode": config.ai.offline_demo_mode,
                        "system_prompt": config.ai.system_prompt,
                        "sql_synth_prompt": config.ai.sql_synth_prompt,
                    }
                },
                user_query=user_message,
                sql=sql_query,
                columns=columns,
                rows=rows,
                error_message=error_text,
            )
        else:
            answer = answer_with_data(
                cfg={
                    "ai": {
                        "provider": config.ai.provider,
                        "model": config.ai.model,
                        "temperature": config.ai.temperature,
                        "offline_demo_mode": config.ai.offline_demo_mode,
                        "system_prompt": config.ai.system_prompt,
                        "sql_synth_prompt": config.ai.sql_synth_prompt,
                    }
                },
                user_query=user_message,
                sql=sql_query,
                columns=columns,
                rows=rows,
            )
        
        return answer
        
    except Exception as e:
        return f"Sorry, I encountered an error: {str(e)}"

@app.route('/webhook/line', methods=['POST'])
def line_webhook():
    """Handle LINE webhook"""
    print("Webhook POST request received")
    
    # Get LINE credentials from saved config file
    try:
        with open('config/line_config.json', 'r') as f:
            line_config = json.load(f)
            channel_secret = line_config.get('channel_secret', '')
            access_token = line_config.get('channel_access_token', '')
    except (FileNotFoundError, json.JSONDecodeError):
        print("Config file not found, using environment variables")
        # Fallback to environment variables
        channel_secret = os.getenv('LINE_CHANNEL_SECRET', '')
        access_token = os.getenv('LINE_ACCESS_TOKEN', '')
    
    if not channel_secret or not access_token:
        print("LINE credentials not configured")
        return "Webhook not configured", 500
    
    # Verify signature
    signature = request.headers.get('X-Line-Signature')
    if not signature:
        print("No X-Line-Signature header found")
        abort(400)
    
    body = request.get_data()
    
    if not verify_line_signature(body, signature, channel_secret):
        print("Signature verification failed")
        abort(400)
    
    # Convert body to text for JSON parsing
    body_text = body.decode('utf-8')
    
    # Parse webhook data
    try:
        webhook_data = json.loads(body_text)
        print(f"Received webhook data: {webhook_data}")
    except json.JSONDecodeError:
        print("Failed to parse JSON data")
        abort(400)
    
    # Process each event
    for event in webhook_data.get('events', []):
        if event['type'] == 'message' and event['message']['type'] == 'text':
            user_message = event['message']['text']
            reply_token = event['replyToken']
            
            # Process the query
            response = process_user_query(user_message)
            
            # Send reply
            send_line_reply(reply_token, response, access_token)
    
    return 'OK', 200

@app.route('/webhook/line', methods=['GET'])
def line_webhook_verify():
    """Handle LINE webhook verification"""
    print("Webhook verification request received")
    return 'OK', 200

@app.route('/', methods=['GET'])
def root():
    """Root endpoint"""
    return {'message': 'LINE Webhook Server is running', 'status': 'ok'}, 200

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return {'status': 'healthy', 'service': 'line-webhook'}, 200

if __name__ == '__main__':
    load_app_data()
    app.run(host='0.0.0.0', port=5000, debug=True)
