
import os
from modules.config_manager import load_config
from modules.ai_agent import _get_embedding_model, calculate_embedding

def debug_embeddings():
    """Debug utility to check embedding functionality"""
    print("🔍 Embedding Debug Report")
    print("=" * 50)
    
    # Check OpenAI API key
    api_key = os.getenv("OPENAI_API_KEY")
    print(f"📋 OpenAI API Key: {'✅ Set' if api_key else '❌ Missing'}")
    
    # Load config
    config = load_config()
    print(f"📋 Config loaded: ✅")
    print(f"📋 Use embedding similarity: {getattr(config.ai, 'use_embedding_similarity', False)}")
    print(f"📋 Use embedding: {getattr(config.ai, 'use_embedding', False)}")
    print(f"📋 Offline demo mode: {config.ai.offline_demo_mode}")
    
    # Check embedding model
    embedding_model = _get_embedding_model()
    print(f"📋 Embedding model: {'✅ Available' if embedding_model else '❌ Not available'}")
    
    # Check snippets
    print(f"\n📊 Snippets Analysis:")
    print(f"Total snippets: {len(config.snippets)}")
    
    for i, snippet in enumerate(config.snippets):
        has_embedding = snippet.embedding is not None
        embedding_len = len(snippet.embedding) if has_embedding else 0
        print(f"  #{i+1}: '{snippet.name[:40]}' - Embedding: {'✅' if has_embedding else '❌'} ({embedding_len} dims)")
    
    # Test embedding calculation
    if embedding_model and api_key and not config.ai.offline_demo_mode:
        print(f"\n🧪 Testing embedding calculation...")
        test_text = "test query"
        test_embedding = calculate_embedding(test_text, embedding_model)
        if test_embedding:
            print(f"✅ Embedding calculation works! Dimensions: {len(test_embedding)}")
        else:
            print(f"❌ Embedding calculation failed")
    else:
        print(f"\n⚠️  Cannot test embedding calculation (API key/model/offline mode issues)")

if __name__ == "__main__":
    debug_embeddings()
