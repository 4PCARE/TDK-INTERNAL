# Streamlit SQL Chat (LangChain) — Minimal Local Demo

Two pages:

- **Chat**: Seamless chatbot UI that turns your question into SQL, runs it against a *simulated* database (from a local CSV/Excel), and answers in natural language.  
- **Config**: Edit prompts, choose the model/provider, toggle offline demo mode, and point to your data file.

---

## 1) Quick Start (Python 3.10+ in a venv)

### Windows (PowerShell)
```powershell
cd streamlit-sql-chat
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt

# Optional: set your OpenAI key (or put it in Config page)
$env:OPENAI_API_KEY="sk-your-key"

streamlit run Chat.py
```

### macOS / Linux
```bash
cd streamlit-sql-chat
python3.13 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt

# Optional: set your OpenAI key (or put it in Config page)
export OPENAI_API_KEY="sk-your-key"

streamlit run Chat.py
```

> If you **don’t** have an API key, enable **Offline Demo Mode** in the Config page. The app will use a lightweight rule-based SQL synthesizer instead of calling a model.

---

## 2) How it Works

- Loads your CSV/Excel into an **in-memory SQLite** table (no server).  
- Uses **LangChain** to synthesize SQL from your query (when a key is set) and to answer with the returned data.  
- When offline, a fallback rule-based SQL generator covers basic patterns (count, sum, top-k, naive filters).

---

## 3) Data

A sample dataset lives at `data/sample_sales.csv`.  
Point the app to your own CSV/XLSX on the **Config** page. The app automatically rebuilds the in-memory table.

---

## 4) Files

```
streamlit-sql-chat/
├─ Chat.py               # Main page (chat UI)
├─ pages/
│  └─ 2_Config.py        # Config page
├─ modules/
│  ├─ ai_agent.py        # LangChain chain + offline fallback
│  ├─ sql_engine.py      # CSV/Excel → SQLite, execute SQL, schema text
│  ├─ config_manager.py  # YAML-backed config (load/save)
│  └─ ui_css.py          # tiny CSS helper for chat bubbles
├─ config/config.yaml    # Saved settings
├─ data/sample_sales.csv # Example data
├─ requirements.txt
└─ README.md
```

---

## 5) Notes

- The app **simulates** SQL over your local file via SQLite. Only `SELECT`/`WITH` queries are executed for safety.  
- If LangChain+OpenAI is configured, the SQL and the final answer are both model-generated. Otherwise it’s the fallback.  
- You can seed a library of “SQL snippets” in Config. The agent sees the *most related* one as extra context.

---

Enjoy hacking. Add retrieval later, swap providers, or pipe to a real DB by replacing `sql_engine.py`.
